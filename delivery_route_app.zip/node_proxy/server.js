
const express = require('express');
const fetch = require('node-fetch');
const app = express();
const PORT = 3000;

app.get('/directions', async (req, res) => {
    const { origin, waypoints, destination, key } = req.query;
    const url = `https://maps.googleapis.com/maps/api/directions/json?origin=${origin}&destination=${destination}&waypoints=optimize:true|${waypoints}&key=${key}`;
    const response = await fetch(url);
    const data = await response.json();
    res.json(data);
});

app.listen(PORT, () => console.log(`Proxy server running on port ${PORT}`));
